package com.wbl.utilities;
public interface Constans {
	
	String path=System.getProperty("user.dir")+"//resources/";
	

}

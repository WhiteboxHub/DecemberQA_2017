package com.wbl.page;

import org.openqa.selenium.WebDriver;

import com.wbl.base.CommonPage;

public class LoginPage extends CommonPage {

	public LoginPage(WebDriver driver) {
		super(driver);
	}

}

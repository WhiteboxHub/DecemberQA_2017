package com.wbl.page;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.wbl.base.CommonPage;

public class SearchResultsPage extends CommonPage{
	
	
	@FindBy(how=How.CSS,using=".chooser-option-current")
	WebElement sortDropDown;
	@FindBy(how=How.CSS,using="[class$='chooser-option']")
	List<WebElement> sortDropDownValues;
	@FindBy(how=How.CSS,using=".Price-group")
	List<WebElement> prices;
	
	
	public SearchResultsPage(WebDriver driver) {
		super(driver);
		}
	
public void selectValueFromSortDropDown(String Value){
	sortDropDown.click();
	for(WebElement Val:sortDropDownValues){
		System.out.println("---------------------");
		if(Val.getText().equals(Value)){
			Val.click();
			break;
		}
	}
}
public float actualMaxPriceINSearchResult(){
	float price =Float.parseFloat(prices.get(1).getText().replaceAll("[^0-9].", ""));
	System.out.println(price);
	return price;
}
public void priceInSearchResults(){
	float max=0;
	for(WebElement elm:prices){
		System.out.println(elm.getText()); //run successfully till now
	
/*public boolean maxpriceInSearchResults(){
			float max=0;
			System.out.println("===========");
			float actualprice =Float.parseFloat(prices.get(0).getText().replaceAll("[^0-9].", ""));
			System.out.println("=====1======");
			System.out.println("Max in List:"+actualprice);
			System.out.println("======2=====");
		for(WebElement elm:prices){
		float price=Float.parseFloat(elm.getText().replaceAll("[^0-9].", ""));
		if(price>max){
			max=price;
			}
		}*/
			/*System.out.println("max");
			return actualprice==max;*/
           
            

	}}
}

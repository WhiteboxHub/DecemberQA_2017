package com.wbl;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wbl.base.Beforetest;
import com.wbl.page.HomePage;
import com.wbl.page.SearchResultsPage;

public class SearchResultsPageTest extends Beforetest {
HomePage hm;	

public SearchResultsPageTest(){
	PageFactory.initElements(driver, SearchResultsPage.class);
}

@Test(groups={"smoke"})
	public void maxPriceSortTest(){
		hm=PageFactory.initElements(driver, HomePage.class);
		SearchResultsPage Sp = hm.search("Laptop");
		Sp.selectValueFromSortDropDown("Price: high to low");
		Sp.priceInSearchResults();
		
		//Assert.assertTrue((Sp.maxpriceInSearchResults()));
	}




}

package com.wbl;


import static org.testng.Assert.assertEquals;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.wbl.base.Beforetest;
import com.wbl.page.HomePage;
import com.wbl.page.SearchResultsPage;


public class HomePageTest extends Beforetest {

	HomePage hm;

	@BeforeMethod
	public void beforeMethod() {
		hm=PageFactory.initElements(driver, HomePage.class);
		//hm = new HomePage(driver);
	}
	@Test(groups={"smoke"})
	public void searchTest() {
		SearchResultsPage Sp= hm.search("Laptop");
		Assert.assertEquals("Laptop - Walmart.com",Sp.getTitle() );}
	
	
	/*@Test
	public void searchTest() {
		String actual = hm.search("Laptop");
		Assert.assertEquals("Laptop - Walmart.com", actual);
	}*/
	@Test(groups={"smoke"})
	public void navgaterLinks(){
		assertEquals(hm.headerNavLinks(), 5);
		
	}

	@Test(groups={"smoke"})
  public void sliderImgTest(){
	assertEquals(hm.sliderimages(), 0);
	
}

















}
